function S = cholDecomposition(P)

%the following algorithm computes S (nxn) such that P = S*S'.  S only
%exists if P is symmetric, positive definite.

%Returns the same thing as chol(P) if S = S' is returned instead of S.

%modified 2/27/2013 ~amb


%Example usage:  P =  [1 2 3; 
%                      2 8 2; 
%                      3 2 14];
%                S = cholDecomposition(P);
%               
%              Output:   S =   [1 0 0; 
%                               2 2 0; 
%                               3 -2 1];              





n = size(P);
S = zeros(size(P));




for i=1:n
    
    if (i == 1)
        S(i,i) = sqrt(P(i,i));
    else
        V = 0;
        for k = 1:i - 1
            V = V + S(i,k)^2;
        end
        
        S(i,i) = sqrt( P(i,i) - V );
    end
    
    
    for j = 1:n
        
        if (j < i)
            S(j,i) = 0;
        else
            
            Q = 0;
            for kk = 1:i - 1
                Q = Q + S(j,kk)*S(i,kk);
            end
            
            S(j,i) = (P(j,i) - Q)/S(i,i);
        end
        
        
    end
      
end
    


