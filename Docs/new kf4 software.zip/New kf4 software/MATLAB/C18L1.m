clear all
close all
SDRE=0;
CHOICE=1;
HP=.001;
W=1.;
A=1.;
TS=.1;
ORDER=3;
PHIS=.1;
SIGX=1.;
T=0.;
S=0.;
H=.001;
IDNP=eye(ORDER);
Q=zeros(ORDER,ORDER);
RMAT(1,1)=SIGX^2;
P=[SIGX^2  0  0;
   0  2.^2  0;
   0  0  2.^2];
XTH=0.;
XTDH=0.;
WH=2.;
XT=0.;
XTD=A*W;
HMAT=[1  0  0];
count=0;
while T<=20.
	XTOLD=XT;
	XTDOLD=XTD;
	XTDD=-W*W*XT;
	XT=XT+H*XTD;
	XTD=XTD+H*XTDD;
	T=T+H;
	XTDD=-W*W*XT;
	XT=.5*(XTOLD+XT+H*XTD);
	XTD=.5*(XTDOLD+XTD+H*XTDD);
	S=S+H;
	if S>=(TS-.00001)
		S=0.;
		if SDRE==0
			F=[0  1  0;
			   -WH^2  0  -2*WH*XTH;
			   0  0  0];
		else
			if CHOICE==1
				F=[0  1  0;
				   0  0  -WH*XTH;
				   0  0  0];
			elseif CHOICE==2
				F=[0  1  0;
				   -WH^2  0  0;
				   0  0  0];
			else
				F=[0  1  0;
				   WH^2  0  -2*WH*XTH;
				   0  0  0];
			end
		end 
		PHI=IDNP+F*TS;
		Q(3,3)=PHIS*TS;
		M=PHI*P*PHI'+Q;
		K = M*HMAT'/(HMAT*M*HMAT' + RMAT);
		P = (IDNP - K*HMAT)*M;
		XTNOISE=SIGX*randn;
		XTMEAS=XT+XTNOISE;
		[XTB,XTDB]=PROJECTC18L1(T,TS,XTH,XTDH,HP,WH);
		RES=XTMEAS-XTB;
		XTH=XTB+K(1,1)*RES;
		XTDH=XTDB+K(2,1)*RES;
		WH=WH+K(3,1)*RES;
		WH=abs(WH);
		ERRW=W-WH;
		SP33=sqrt(P(3,3));
		SP33P=-SP33;
		count=count+1;
		ArrayT(count)=T;
		ArrayW(count)=W;
		ArrayWH(count)=WH;
		ArrayERRW(count)=ERRW;
		ArraySP33(count)=SP33;
		ArraySP33P(count)=SP33P;
	end
end
figure
plot(ArrayT,ArrayW,ArrayT,ArrayWH),grid
xlabel('Time (Sec)')
ylabel('Frequency (R/S)')
figure
plot(ArrayT,ArrayERRW,ArrayT,ArraySP33,ArrayT,ArraySP33P),grid
xlabel('Time (Sec)')
ylabel('Error in Frequency (R/S)')
clc
output=[ArrayT',ArrayW',ArrayWH',ArrayERRW',ArraySP33',ArraySP33P'];
save datfil.txt output  -ascii
disp 'simulation finished'
			 
			 
			 

	