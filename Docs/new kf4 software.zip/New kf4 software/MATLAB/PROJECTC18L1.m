function [XTH,XTDH]=projectc18l1(TP,TS,XTP,XTDP,HP,W)
T=0.;
XT=XTP;
XTD=XTDP;
H=HP;
while T<=(TS-.0001)
	XTDD=-W*W*XT;
	XTD=XTD+H*XTDD;
	XT=XT+H*XTD;
	T=T+H;
end
XTH=XT;
XTDH=XTD;
			 
			 
			 

	